"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "../supabase";

type Evento = {
  id: number;
  titulo: string;
  data: string;
  horario: string;
  local: string;
  descricao?: string | null;
  criado_em?: string;
};

const meses = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];

const mesesAbrev = [
  "JAN",
  "FEV",
  "MAR",
  "ABR",
  "MAI",
  "JUN",
  "JUL",
  "AGO",
  "SET",
  "OUT",
  "NOV",
  "DEZ",
];

export default function Home() {
  const agora = new Date();

  const [mesAtual, setMesAtual] = useState(agora.getMonth());
  const [anoAtual, setAnoAtual] = useState(agora.getFullYear());

  const [eventos, setEventos] = useState<Evento[]>([]);
  const [usuario, setUsuario] = useState<any>(null);
  const [carregandoUsuario, setCarregandoUsuario] = useState(true);

  const [mostrarLogin, setMostrarLogin] = useState(false);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);

  const [eventoSelecionado, setEventoSelecionado] =
    useState<Evento | null>(null);

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [titulo, setTitulo] = useState("");
  const [data, setData] = useState("");
  const [horario, setHorario] = useState("");
  const [local, setLocal] = useState("");
  const [descricao, setDescricao] = useState("");

  const [eventoEditando, setEventoEditando] = useState<Evento | null>(null);

  /* =========================
     AUTENTICAÇÃO
  ========================= */

  useEffect(() => {
    verificarUsuario();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUsuario(session?.user ?? null);
      setCarregandoUsuario(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function verificarUsuario() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    setUsuario(user);
    setCarregandoUsuario(false);
  }

  async function entrar() {
    if (!email || !senha) {
      alert("Preencha o e-mail e a senha.");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password: senha,
    });

    if (error) {
      alert("E-mail ou senha incorretos.");
      console.error(error);
      return;
    }

    setMostrarLogin(false);
    setEmail("");
    setSenha("");
  }

  async function sair() {
    await supabase.auth.signOut();
  }

  /* =========================
     EVENTOS
  ========================= */

  useEffect(() => {
    carregarEventos();
  }, [mesAtual, anoAtual]);

  async function carregarEventos() {
    const primeiroDia = new Date(anoAtual, mesAtual, 1)
      .toISOString()
      .split("T")[0];

    const ultimoDia = new Date(anoAtual, mesAtual + 1, 0)
      .toISOString()
      .split("T")[0];

    const { data, error } = await supabase
      .from("eventos")
      .select("*")
      .gte("data", primeiroDia)
      .lte("data", ultimoDia)
      .order("data", { ascending: true })
      .order("horario", { ascending: true });

    if (error) {
      console.error(error);
      return;
    }

    setEventos(data || []);
  }

  function abrirNovoEvento() {
    setEventoEditando(null);
    setTitulo("");
    setData("");
    setHorario("");
    setLocal("");
    setDescricao("");
    setMostrarFormulario(true);
  }

  function abrirEditarEvento(evento: Evento) {
    setEventoEditando(evento);

    setTitulo(evento.titulo);
    setData(evento.data);
    setHorario(evento.horario?.slice(0, 5) || "");
    setLocal(evento.local);
    setDescricao(evento.descricao || "");

    setMostrarFormulario(true);
  }

  async function salvarEvento() {
    if (!titulo || !data || !horario || !local) {
      alert("Preencha título, data, horário e local.");
      return;
    }

    if (eventoEditando) {
      const { error } = await supabase
        .from("eventos")
        .update({
          titulo,
          data,
          horario,
          local,
          descricao,
        })
        .eq("id", eventoEditando.id);

      if (error) {
        console.error(error);
        alert("Não foi possível editar o evento.");
        return;
      }
    } else {
      const { error } = await supabase.from("eventos").insert({
        titulo,
        data,
        horario,
        local,
        descricao,
      });

      if (error) {
        console.error(error);
        alert("Não foi possível criar o evento.");
        return;
      }
    }

    setMostrarFormulario(false);
    carregarEventos();
  }

  async function excluirEvento(id: number) {
    const confirmar = confirm("Deseja realmente excluir este evento?");

    if (!confirmar) return;

    const { error } = await supabase
      .from("eventos")
      .delete()
      .eq("id", id);

    if (error) {
      console.error(error);
      alert("Não foi possível excluir o evento.");
      return;
    }

    setEventoSelecionado(null);
    carregarEventos();
  }

  /* =========================
     NAVEGAÇÃO
  ========================= */

  function mesAnterior() {
    if (mesAtual === 0) {
      setMesAtual(11);
      setAnoAtual(anoAtual - 1);
    } else {
      setMesAtual(mesAtual - 1);
    }
  }

  function proximoMes() {
    if (mesAtual === 11) {
      setMesAtual(0);
      setAnoAtual(anoAtual + 1);
    } else {
      setMesAtual(mesAtual + 1);
    }
  }

  /* =========================
     DATAS
  ========================= */

  function formatarData(dataEvento: string) {
    const [ano, mes, dia] = dataEvento.split("-").map(Number);

    return {
      dia,
      mes: mesesAbrev[mes - 1],
      dataCompleta: `${dia} de ${meses[mes - 1]} de ${ano}`,
    };
  }

  function calcularDias(dataEvento: string) {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const [ano, mes, dia] = dataEvento.split("-").map(Number);

    const dataAlvo = new Date(ano, mes - 1, dia);
    dataAlvo.setHours(0, 0, 0, 0);

    const diferenca =
      dataAlvo.getTime() - hoje.getTime();

    return Math.ceil(diferenca / (1000 * 60 * 60 * 24));
  }

  const eventosDoMes = useMemo(() => {
    return eventos;
  }, [eventos]);

  const proximoEvento = eventosDoMes.length > 0
    ? eventosDoMes[0]
    : null;

  /* =========================
     WHATSAPP
  ========================= */

  function compartilharWhatsApp() {
    const mensagem =
      "📅 *Calendário EJC*\n\n" +
      "Confira os próximos eventos e tudo que acontece no EJC:\n\n" +
      window.location.href;

    const url =
      `https://wa.me/?text=${encodeURIComponent(mensagem)}`;

    window.open(url, "_blank");
  }

  if (carregandoUsuario) {
    return (
      <main className="loading-screen">
        <div className="loading-logo">
          EJC
        </div>
      </main>
    );
  }

  return (
    <main className="page">

      {/* =========================
          DECORAÇÕES DOURADAS
      ========================= */}

      <div className="decor decorTopLeft">
        <svg viewBox="0 0 300 360">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M15 315 C45 250, 35 190, 80 135 C110 98, 150 78, 182 52" />
            <path d="M65 246 C43 214, 28 181, 32 143" />
            <path d="M90 206 C120 178, 138 151, 151 119" />

            <path d="M76 157 C44 141, 26 115, 27 91 C28 66, 50 53, 70 63 C90 73, 94 96, 82 116" />
            <path d="M78 157 C110 141, 130 114, 128 89 C126 64, 104 52, 84 63 C65 74, 63 98, 75 117" />

            <path d="M76 157 C60 136, 60 110, 76 97 C91 84, 111 91, 116 108 C121 126, 104 145, 76 157" />

            <path d="M65 246 C37 235, 18 218, 13 198 C35 193, 57 204, 65 246" />
            <path d="M89 206 C111 205, 132 192, 142 174 C118 169, 98 180, 89 206" />
          </g>
        </svg>
      </div>

      <div className="decor decorTopRight">
        <svg viewBox="0 0 260 240">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.35"
            strokeLinecap="round"
          >
            <path d="M245 20 C205 50, 188 90, 184 135 C181 168, 192 196, 217 218" />
            <path d="M210 73 C190 65, 172 67, 160 79 C178 91, 196 90, 210 73" />
            <path d="M190 133 C210 121, 226 122, 239 135 C220 148, 202 147, 190 133" />
            <path d="M183 176 C163 165, 146 168, 135 182 C153 192, 171 190, 183 176" />

            <path d="M216 54 C225 48, 236 50, 240 59 C244 68, 238 77, 229 81 C221 75, 216 65, 216 54Z" />
          </g>
        </svg>
      </div>

      <div className="decor decorBottomLeft">
        <svg viewBox="0 0 260 300">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.25"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M18 285 C42 246, 68 223, 74 183 C79 151, 66 124, 39 104" />
            <path d="M74 183 C104 167, 125 142, 130 111" />
            <path d="M57 221 C36 211, 20 194, 18 174 C39 174, 56 192, 57 221" />
            <path d="M88 162 C108 160, 125 149, 136 131 C115 127, 97 138, 88 162" />

            <path d="M47 76 C48 52, 62 34, 80 29 C84 51, 72 69, 47 76" />
            <path d="M47 76 C27 68, 15 53, 15 37 C32 39, 46 53, 47 76" />
          </g>
        </svg>
      </div>

      <div className="decor decorBottomRight">
        <svg viewBox="0 0 300 340">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M285 330 C258 285, 248 247, 259 205 C270 162, 252 124, 215 95" />

            <path d="M252 244 C226 229, 208 205, 207 179 C231 183, 250 204, 252 244" />

            <path d="M257 205 C281 190, 293 166, 289 143 C268 148, 255 172, 257 205" />

            <path d="M215 95 C190 82, 174 59, 176 36 C198 41, 215 63, 215 95" />

            <path d="M216 95 C239 85, 252 64, 250 43 C229 48, 216 68, 216 95" />

            <path d="M195 137 C207 125, 209 109, 203 97 C190 107, 187 123, 195 137" />

            <path d="M207 179 C188 166, 172 165, 159 176 C176 188, 193 188, 207 179" />
          </g>
        </svg>
      </div>

      {/* pequenos brilhos */}

      <span className="goldStar star1">✦</span>
      <span className="goldStar star2">✦</span>
      <span className="goldStar star3">✦</span>
      <span className="goldStar star4">✦</span>
      <span className="goldStar star5">✦</span>

      {/* =========================
          CONTEÚDO
      ========================= */}

      <div className="content">

        {/* HEADER */}

        <header className="header">

          <div className="brand">

            <div className="logoArea">
              <img
                src="/logo-ejc.png"
                alt="EJC - Encontro de Jovens com Cristo"
                className="logo"
              />
            </div>

            <div className="brandDivider" />

            <div className="titleArea">
              <span className="smallTitle">
                CALENDÁRIO DE
              </span>

              <h1>Eventos</h1>

              <span className="subtitle">
                ENCONTRO DE JOVENS COM CRISTO
              </span>

              <div className="titleDecoration">
                <span />
                <b>♡</b>
                <span />
              </div>
            </div>

          </div>

          <div className="headerButtons">

            <button
              className="outlineButton"
              onClick={compartilharWhatsApp}
            >
              <span>✦</span>
              Compartilhar
            </button>

            {usuario ? (
              <>
                <button
                  className="outlineButton"
                  onClick={abrirNovoEvento}
                >
                  + Novo evento
                </button>

                <button
                  className="outlineButton"
                  onClick={sair}
                >
                  Sair
                </button>
              </>
            ) : (
              <button
                className="outlineButton"
                onClick={() => setMostrarLogin(true)}
              >
                ♟ Área da equipe
              </button>
            )}

          </div>

        </header>

        {/* =========================
            PRÓXIMO EVENTO
        ========================= */}

        {proximoEvento && (
          <section
            className="featuredEvent"
            onClick={() => setEventoSelecionado(proximoEvento)}
          >

            <div className="featuredDate">

              <div className="nextBadge">
                PRÓXIMO EVENTO
              </div>

              <strong>
                {formatarData(proximoEvento.data).dia}
              </strong>

              <span className="featuredMonth">
                {formatarData(proximoEvento.data).mes}
              </span>

              <div className="featuredInfo">
                <span>
                  ◷ {proximoEvento.horario.slice(0, 5)}
                </span>

                <span>
                  ♢ {proximoEvento.local}
                </span>
              </div>

            </div>

            <div className="featuredContent">

              <h2>{proximoEvento.titulo}</h2>

              <p>
                {proximoEvento.descricao ||
                  "Um encontro especial de oração, comunhão e muita alegria."}
              </p>

              <div className="daysBadge">
                ◷{" "}
                {calcularDias(proximoEvento.data) > 0
                  ? `Faltam ${calcularDias(proximoEvento.data)} dias`
                  : calcularDias(proximoEvento.data) === 0
                  ? "É hoje!"
                  : "Evento realizado"}
              </div>

            </div>

          </section>
        )}

        {/* =========================
            MÊS
        ========================= */}

        <section className="monthSection">

          <div className="monthNavigation">

            <button
              className="monthArrow"
              onClick={mesAnterior}
            >
              ‹
            </button>

            <div className="monthTitle">
              <h2>{meses[mesAtual]}</h2>

              <span>{anoAtual}</span>
            </div>

            <button
              className="monthArrow"
              onClick={proximoMes}
            >
              ›
            </button>

          </div>

          <p className="monthDescription">
            Confira tudo o que acontece no EJC neste mês.
          </p>

          <div className="monthDecoration">
            <span />
            <b>♡</b>
            <span />
          </div>

        </section>

        {/* =========================
            EVENTOS
        ========================= */}

        {eventosDoMes.length === 0 ? (

          <div className="emptyState">

            <div className="emptySymbol">✦</div>

            <h3>
              Nenhum evento neste mês
            </h3>

            <p>
              Em breve teremos novidades por aqui.
            </p>

            {usuario && (
              <button
                className="goldButton"
                onClick={abrirNovoEvento}
              >
                Adicionar evento
              </button>
            )}

          </div>

        ) : (

          <section className="eventsGrid">

            {eventosDoMes.map((evento) => {

              const info = formatarData(evento.data);

              return (
                <article
                  key={evento.id}
                  className="eventCard"
                  onClick={() =>
                    setEventoSelecionado(evento)
                  }
                >

                  <div className="cardTop">

                    <div>
                      <strong>
                        {info.dia}
                      </strong>

                      <span>
                        {info.mes}
                      </span>
                    </div>

                    <div className="timeBox">
                      <small>
                        HORÁRIO:
                      </small>

                      <b>
                        {evento.horario.slice(0, 5)}
                      </b>
                    </div>

                  </div>

                  <h3>
                    {evento.titulo}
                  </h3>

                  <p>
                    {evento.descricao ||
                      "Evento do EJC. Clique para visualizar todos os detalhes."}
                  </p>

                  <div className="cardBottom">
                    <span>
                      ♢ {evento.local}
                    </span>

                    <b>→</b>
                  </div>

                </article>
              );
            })}

          </section>

        )}

        {/* =========================
            RODAPÉ
        ========================= */}

        <footer className="footer">

          <div className="footerDecoration">
            <span />
            <b>♡</b>
            <span />
          </div>

          <p>
            EJC • Encontro de Jovens com Cristo
          </p>

          <small>
            Paróquia de Sant’Ana do Barroso
          </small>

        </footer>

      </div>

      {/* =========================
          MODAL EVENTO
      ========================= */}

      {eventoSelecionado && (

        <div
          className="modalOverlay"
          onClick={() => setEventoSelecionado(null)}
        >

          <div
            className="eventModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() => setEventoSelecionado(null)}
            >
              ×
            </button>

            <span className="modalLabel">
              EVENTO DO EJC
            </span>

            <h2>
              {eventoSelecionado.titulo}
            </h2>

            <div className="modalDivider" />

            <div className="modalInfo">

              <div>
                <small>DATA</small>
                <strong>
                  {formatarData(eventoSelecionado.data).dataCompleta}
                </strong>
              </div>

              <div>
                <small>HORÁRIO</small>
                <strong>
                  {eventoSelecionado.horario.slice(0, 5)}
                </strong>
              </div>

              <div>
                <small>LOCAL</small>
                <strong>
                  {eventoSelecionado.local}
                </strong>
              </div>

            </div>

            {eventoSelecionado.descricao && (
              <p className="modalDescription">
                {eventoSelecionado.descricao}
              </p>
            )}

            {usuario && (
              <div className="modalActions">

                <button
                  className="editButton"
                  onClick={() => {
                    abrirEditarEvento(eventoSelecionado);
                    setEventoSelecionado(null);
                  }}
                >
                  Editar
                </button>

                <button
                  className="deleteButton"
                  onClick={() =>
                    excluirEvento(eventoSelecionado.id)
                  }
                >
                  Excluir
                </button>

              </div>
            )}

          </div>

        </div>

      )}

      {/* =========================
          LOGIN
      ========================= */}

      {mostrarLogin && (

        <div
          className="modalOverlay"
          onClick={() => setMostrarLogin(false)}
        >

          <div
            className="loginModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() => setMostrarLogin(false)}
            >
              ×
            </button>

            <div className="loginSymbol">
              ✦
            </div>

            <span className="modalLabel">
              ÁREA RESTRITA
            </span>

            <h2>
              Área da equipe
            </h2>

            <p>
              Entre para gerenciar os eventos do EJC.
            </p>

            <input
              type="email"
              placeholder="E-mail"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
            />

            <input
              type="password"
              placeholder="Senha"
              value={senha}
              onChange={(e) =>
                setSenha(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  entrar();
                }
              }}
            />

            <button
              className="loginButton"
              onClick={entrar}
            >
              Entrar
            </button>

          </div>

        </div>

      )}

      {/* =========================
          FORMULÁRIO
      ========================= */}

      {mostrarFormulario && (

        <div
          className="modalOverlay"
          onClick={() => setMostrarFormulario(false)}
        >

          <div
            className="formModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() =>
                setMostrarFormulario(false)
              }
            >
              ×
            </button>

            <span className="modalLabel">
              ÁREA DA EQUIPE
            </span>

            <h2>
              {eventoEditando
                ? "Editar evento"
                : "Novo evento"}
            </h2>

            <div className="formGrid">

              <label>
                Título
                <input
                  value={titulo}
                  onChange={(e) =>
                    setTitulo(e.target.value)
                  }
                  placeholder="Ex.: Encontro do EJC"
                />
              </label>

              <label>
                Data
                <input
                  type="date"
                  value={data}
                  onChange={(e) =>
                    setData(e.target.value)
                  }
                />
              </label>

              <label>
                Horário
                <input
                  type="time"
                  value={horario}
                  onChange={(e) =>
                    setHorario(e.target.value)
                  }
                />
              </label>

              <label>
                Local
                <input
                  value={local}
                  onChange={(e) =>
                    setLocal(e.target.value)
                  }
                  placeholder="Ex.: Matriz Sant'Ana"
                />
              </label>

              <label className="full">
                Descrição
                <textarea
                  value={descricao}
                  onChange={(e) =>
                    setDescricao(e.target.value)
                  }
                  placeholder="Digite uma breve descrição do evento..."
                  rows={4}
                />
              </label>

            </div>

            <button
              className="saveButton"
              onClick={salvarEvento}
            >
              {eventoEditando
                ? "Salvar alterações"
                : "Adicionar evento"}
            </button>

          </div>

        </div>

      )}

      <style jsx global>{`:root{--blue:#08295f;--blue-dark:#061f4c;--gold:#e7ad2f;--gold-light:#f4c94f;--white:#fff;--text:#0a2b5c;--text-soft:#526987;--border:#e4eaf1;--shadow-sm:0 1px 2px rgba(6,31,76,.04),0 4px 12px rgba(6,31,76,.04);--shadow-md:0 4px 10px rgba(6,31,76,.05),0 12px 28px rgba(6,31,76,.08);--shadow-lg:0 8px 20px rgba(6,31,76,.06),0 24px 50px rgba(6,31,76,.12);--radius-md:12px;--radius-lg:16px;--radius-xl:20px;--transition:all .2s ease-in-out}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-width:320px;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--blue);color:var(--white);-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}button,input,textarea{font:inherit}button{cursor:pointer}img{max-width:100%;display:block}.page{position:relative;min-height:100vh;overflow:hidden;background:radial-gradient(circle at 50% 10%,rgba(25,74,145,.28),transparent 38%),linear-gradient(135deg,#071f4b 0%,#092b64 50%,#061f4c 100%)}.content{position:relative;z-index:5;width:min(1120px,calc(100% - 48px));margin:0 auto;padding:40px 0 64px}.decor{position:absolute;color:rgba(231,173,47,.45);pointer-events:none;user-select:none;z-index:1;transition:var(--transition)}.decorTopLeft{width:260px;height:320px;top:80px;left:-25px}.decorTopRight{width:230px;height:230px;top:170px;right:-5px}.decorBottomLeft{width:220px;height:270px;bottom:20px;left:-10px}.decorBottomRight{width:270px;height:320px;right:-5px;bottom:-15px}.goldStar{position:absolute;z-index:2;color:var(--gold);font-size:16px;opacity:.8;pointer-events:none}.header{display:flex;align-items:flex-start;justify-content:space-between;gap:32px;margin-bottom:48px}.brand{display:flex;align-items:center;gap:20px}.logoArea{width:200px;min-width:200px;display:flex;align-items:center;justify-content:center}.logo{width:200px;height:auto;transform:translateY(-25px);transition:var(--transition)}.brandDivider{width:1px;height:96px;background:rgba(231,173,47,.7)}.titleArea{padding-top:4px}.smallTitle{display:block;margin-bottom:4px;color:var(--white);font-size:13px;font-weight:700;letter-spacing:6px;line-height:1.2}.titleArea h1{margin:0;color:var(--gold-light);font-family:Georgia,"Times New Roman",serif;font-size:clamp(56px,7vw,84px);font-weight:500;font-style:italic;line-height:.95;letter-spacing:-.03em}.subtitle{display:block;margin-top:12px;color:var(--white);font-size:9px;font-weight:700;letter-spacing:4px;line-height:1.4}.titleDecoration,.monthDecoration,.footerDecoration{display:flex;align-items:center;justify-content:center;gap:16px}.titleDecoration{margin-top:24px}.titleDecoration span,.monthDecoration span,.footerDecoration span{height:1px;background:rgba(231,173,47,.68)}.titleDecoration span{width:144px}.titleDecoration b,.monthDecoration b,.footerDecoration b{color:var(--gold);font-size:18px;font-weight:400}.headerButtons{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:8px;padding-top:6px}.outlineButton{min-height:40px;padding:0 16px;border:1px solid rgba(231,173,47,.9);border-radius:999px;background:rgba(6,31,76,.24);color:var(--white);font-size:12px;font-weight:700;transition:var(--transition)}.outlineButton:hover{background:var(--gold);border-color:var(--gold);color:var(--blue);transform:translateY(-1px);box-shadow:0 4px 10px rgba(231,173,47,.18)}.outlineButton:active{transform:translateY(0)}.featuredEvent{display:grid;grid-template-columns:192px minmax(0,1fr);min-height:192px;overflow:hidden;border:1px solid rgba(231,173,47,.65);border-radius:var(--radius-xl);background:var(--white);box-shadow:var(--shadow-lg);cursor:pointer;transition:var(--transition)}.featuredEvent:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(6,31,76,.08),0 28px 55px rgba(6,31,76,.16)}.featuredDate{position:relative;display:flex;flex-direction:column;padding:40px 24px 24px;background:linear-gradient(145deg,#0d3979,#092b62)}.nextBadge{position:absolute;top:0;left:16px;padding:8px 14px;border-radius:0 0 10px 10px;background:var(--gold-light);color:var(--blue);font-size:9px;font-weight:800}.featuredDate strong{color:var(--white);font-size:62px;font-weight:800;line-height:.9;letter-spacing:-.04em}.featuredMonth{margin-top:8px;color:var(--gold-light);font-size:18px;font-weight:800}.featuredInfo{display:flex;flex-direction:column;gap:8px;margin-top:auto;color:rgba(255,255,255,.82);font-size:10px;font-weight:600;line-height:1.4}.featuredContent{display:flex;flex-direction:column;justify-content:center;padding:32px 40px;color:var(--text)}.featuredContent h2{margin:0 0 8px;color:var(--text);font-size:26px;font-weight:600;line-height:1.2;letter-spacing:-.025em}.featuredContent p{max-width:680px;margin:0 0 16px;color:var(--text-soft);font-size:13px;line-height:1.6}.daysBadge{width:fit-content;padding:8px 14px;border:1px solid rgba(231,173,47,.7);border-radius:999px;color:#9a6b00;font-size:11px;font-weight:700;background:rgba(244,201,79,.08);transition:var(--transition)}.monthSection{text-align:center;padding:40px 0 28px}.monthNavigation{display:flex;align-items:center;justify-content:center;gap:24px}.monthArrow{width:42px;height:42px;display:grid;place-items:center;flex:0 0 auto;border:1px solid rgba(231,173,47,.8);border-radius:50%;background:rgba(255,255,255,.02);color:var(--gold-light);font-size:28px;line-height:1;transition:var(--transition)}.monthArrow:hover{background:var(--gold);border-color:var(--gold);color:var(--blue);transform:translateY(-1px);box-shadow:0 5px 12px rgba(231,173,47,.18)}.monthArrow:active{transform:translateY(0)}.monthTitle h2{margin:0;color:var(--gold-light);font-family:Georgia,"Times New Roman",serif;font-size:clamp(44px,5vw,58px);font-weight:500;font-style:italic;line-height:1;letter-spacing:-.025em}.monthTitle span{display:block;margin-top:8px;color:var(--white);font-size:10px;font-weight:800;letter-spacing:6px}.monthDescription{margin:12px 0 0;color:rgba(255,255,255,.78);font-size:12px;line-height:1.5}.monthDecoration{margin-top:20px}.monthDecoration span{width:176px}.eventsGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.eventCard{position:relative;min-width:0;min-height:224px;padding:16px;overflow:hidden;border:1px solid rgba(231,173,47,.65);border-radius:var(--radius-lg);background:var(--white);color:var(--text);box-shadow:var(--shadow-md);cursor:pointer;transition:var(--transition)}.eventCard:hover{transform:translateY(-4px);border-color:rgba(231,173,47,.95);box-shadow:0 5px 12px rgba(6,31,76,.06),0 16px 30px rgba(6,31,76,.12)}.eventCard:active{transform:translateY(-1px)}.cardTop{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.cardTop>div:first-child strong{display:block;color:#0b3979;font-size:38px;font-weight:800;line-height:.9;letter-spacing:-.04em}.cardTop>div:first-child span{display:block;margin-top:6px;color:#b17b00;font-size:11px;font-weight:800}.timeBox{min-width:82px;padding:7px 11px;border-radius:10px;background:var(--gold-light);color:var(--blue);transition:var(--transition)}.timeBox small{display:block;font-size:7px;font-weight:800}.timeBox b{display:block;margin-top:3px;font-size:13px;font-weight:800}.eventCard h3{margin:20px 0 8px;color:var(--text);font-size:17px;font-weight:600;line-height:1.3;letter-spacing:-.015em}.eventCard p{min-height:42px;margin:0;color:var(--text-soft);font-size:11px;line-height:1.55}.cardBottom{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px;padding-top:12px;border-top:1px solid var(--border);color:#426082;font-size:10px;font-weight:600}.cardBottom b{color:var(--gold);font-size:18px;font-weight:500}.emptyState{padding:48px 24px;border:1px solid rgba(231,173,47,.35);border-radius:var(--radius-xl);background:rgba(255,255,255,.035);text-align:center}.goldButton,.editButton,.saveButton{border:0;background:var(--gold);color:var(--blue);font-weight:800;transition:var(--transition)}.goldButton:hover,.editButton:hover,.saveButton:hover{background:var(--gold-light);transform:translateY(-1px);box-shadow:0 5px 12px rgba(231,173,47,.18)}.footer{padding:48px 0 0;text-align:center}.footerDecoration span{width:136px}.footer p{margin:16px 0 4px;color:var(--white);font-size:10px;font-weight:700;letter-spacing:2px}.footer small{color:rgba(255,255,255,.58);font-size:10px}.modalOverlay{position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(2,13,34,.76);backdrop-filter:blur(7px)}.eventModal,.loginModal,.formModal{position:relative;width:min(520px,100%);padding:32px;border:1px solid rgba(231,173,47,.28);border-radius:var(--radius-xl);background:var(--white);color:var(--text);box-shadow:0 10px 25px rgba(6,31,76,.12),0 30px 70px rgba(2,13,34,.3);animation:modalIn .2s ease-in-out}.formModal{width:min(650px,100%);max-height:calc(100vh - 48px);overflow-y:auto}@keyframes modalIn{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}.closeButton{position:absolute;top:16px;right:16px;width:36px;height:36px;display:grid;place-items:center;border:1px solid var(--border);border-radius:50%;background:#f8fafc;color:#24466d;font-size:20px;transition:var(--transition)}.closeButton:hover{background:#eef2f7;transform:rotate(4deg)}.eventModal h2,.loginModal h2,.formModal h2{margin:0;color:var(--text);font-family:Georgia,"Times New Roman",serif;font-size:34px;font-weight:500;line-height:1.15}.modalDivider{height:1px;margin:20px 0;background:var(--gold)}.modalInfo{display:grid;gap:16px}.modalInfo small{display:block;margin-bottom:4px;color:#a67a18;font-size:8px;font-weight:800;letter-spacing:2px}.modalInfo strong{color:var(--text);font-size:14px}.modalDescription{margin-top:20px;color:var(--text-soft);font-size:13px;line-height:1.6}.modalActions{display:flex;gap:8px;margin-top:24px}.editButton,.deleteButton{min-height:40px;padding:0 16px;border-radius:999px;font-size:12px;font-weight:700}.deleteButton{border:0;background:#f9eeee;color:#9a2929;transition:var(--transition)}.deleteButton:hover{background:#f4dddd;transform:translateY(-1px)}.loginModal>p{margin:8px 0 20px;color:var(--text-soft);font-size:13px}.loginModal input,.formModal input,.formModal textarea{width:100%;border:1px solid #d8e0e9;border-radius:var(--radius-md);padding:11px 12px;outline:none;background:#fafbfd;color:var(--text);font-size:13px;transition:var(--transition)}.loginModal input:focus,.formModal input:focus,.formModal textarea:focus{border-color:var(--gold);background:#fff;box-shadow:0 0 0 3px rgba(231,173,47,.1)}.loginButton,.saveButton{width:100%;min-height:42px;margin-top:8px;border-radius:var(--radius-md)}.formGrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:24px}.formGrid label{display:flex;flex-direction:column;gap:6px;color:#365675;font-size:11px;font-weight:700}.formGrid label.full{grid-column:1/-1}.formGrid textarea{min-height:110px;resize:vertical}.loading-screen{min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--blue)}.loading-logo{color:var(--gold);font-family:Georgia,"Times New Roman",serif;font-size:60px;font-style:italic}@media(max-width:900px){.content{width:min(720px,calc(100% - 32px))}.header{flex-direction:column;gap:24px}.headerButtons{width:100%;justify-content:flex-start}.eventsGrid{grid-template-columns:repeat(2,minmax(0,1fr))}.decorTopLeft,.decorBottomLeft{opacity:.5}}@media(max-width:650px){.content{width:calc(100% - 24px);padding-top:24px;padding-bottom:48px}.header{margin-bottom:32px}.brand{width:100%;gap:12px}.logoArea{width:80px;min-width:80px}.logo{width:80px;max-width:80px;max-height:80px;transform:translateY(-10px)}.brandDivider{height:72px}.smallTitle{font-size:8px;letter-spacing:3px}.titleArea h1{font-size:52px}.subtitle{margin-top:8px;font-size:7px;letter-spacing:2px}.titleDecoration{gap:10px;margin-top:16px}.titleDecoration span{width:60px}.outlineButton{min-height:36px;padding:0 12px;font-size:10px}.featuredEvent{grid-template-columns:104px minmax(0,1fr);min-height:180px;border-radius:16px}.featuredDate{padding:38px 12px 16px}.featuredDate strong{font-size:46px}.featuredMonth{font-size:14px}.featuredInfo{gap:5px;font-size:8px}.featuredContent{padding:22px 16px}.featuredContent h2{font-size:20px}.featuredContent p{font-size:11px}.monthSection{padding:32px 0 24px}.monthNavigation{gap:14px}.monthArrow{width:36px;height:36px;font-size:24px}.monthTitle h2{font-size:44px}.monthTitle span{font-size:8px;letter-spacing:4px}.monthDescription{font-size:11px}.monthDecoration{gap:10px}.monthDecoration span{width:58px}.eventsGrid{grid-template-columns:1fr;gap:16px}.eventCard{min-height:205px}.decorTopLeft{top:70px;left:-85px;opacity:.35}.decorTopRight{top:150px;right:-90px;opacity:.35}.decorBottomLeft{left:-100px;opacity:.3}.decorBottomRight{right:-105px;opacity:.3}.formGrid{grid-template-columns:1fr;gap:12px}.formGrid label.full{grid-column:auto}.modalOverlay{padding:12px}.eventModal,.loginModal,.formModal{padding:28px 20px;border-radius:16px}.eventModal h2,.loginModal h2,.formModal h2{font-size:30px}.modalActions{flex-direction:column}.editButton,.deleteButton{width:100%}}@media(max-width:400px){.content{width:calc(100% - 16px)}.brand{gap:8px}.logoArea{width:68px;min-width:68px}.logo{width:68px;max-width:68px}.brandDivider{height:62px}.smallTitle{font-size:7px;letter-spacing:2px}.titleArea h1{font-size:43px}.subtitle{font-size:6px;letter-spacing:1.5px}.featuredEvent{grid-template-columns:88px minmax(0,1fr)}.featuredDate{padding-left:10px;padding-right:10px}.featuredDate strong{font-size:40px}.featuredMonth{font-size:12px}.featuredContent{padding:18px 12px}.featuredContent h2{font-size:17px}.featuredContent p{font-size:10px}.monthTitle h2{font-size:39px}}@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:.01ms!important}}`}</style>

    </main>
  );
}