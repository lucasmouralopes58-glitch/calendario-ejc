"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "../supabase";

type Evento = {
  id: number;
  titulo: string;
  data: string;
  horario: string;
  local: string;
  descricao?: string | null;
  criado_em?: string;
};

const meses = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];

const mesesAbrev = [
  "JAN",
  "FEV",
  "MAR",
  "ABR",
  "MAI",
  "JUN",
  "JUL",
  "AGO",
  "SET",
  "OUT",
  "NOV",
  "DEZ",
];

export default function Home() {
  const agora = new Date();

  const [mesAtual, setMesAtual] = useState(agora.getMonth());
  const [anoAtual, setAnoAtual] = useState(agora.getFullYear());

  const [eventos, setEventos] = useState<Evento[]>([]);
  const [usuario, setUsuario] = useState<any>(null);
  const [carregandoUsuario, setCarregandoUsuario] = useState(true);

  const [mostrarLogin, setMostrarLogin] = useState(false);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);

  const [eventoSelecionado, setEventoSelecionado] =
    useState<Evento | null>(null);

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [titulo, setTitulo] = useState("");
  const [data, setData] = useState("");
  const [horario, setHorario] = useState("");
  const [local, setLocal] = useState("");
  const [descricao, setDescricao] = useState("");

  const [eventoEditando, setEventoEditando] = useState<Evento | null>(null);

  /* =========================
     AUTENTICAÇÃO
  ========================= */

  useEffect(() => {
    verificarUsuario();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUsuario(session?.user ?? null);
      setCarregandoUsuario(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  async function verificarUsuario() {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    setUsuario(user);
    setCarregandoUsuario(false);
  }

  async function entrar() {
    if (!email || !senha) {
      alert("Preencha o e-mail e a senha.");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password: senha,
    });

    if (error) {
      alert("E-mail ou senha incorretos.");
      console.error(error);
      return;
    }

    setMostrarLogin(false);
    setEmail("");
    setSenha("");
  }

  async function sair() {
    await supabase.auth.signOut();
  }

  /* =========================
     EVENTOS
  ========================= */

  useEffect(() => {
    carregarEventos();
  }, [mesAtual, anoAtual]);

  async function carregarEventos() {
    const primeiroDia = new Date(anoAtual, mesAtual, 1)
      .toISOString()
      .split("T")[0];

    const ultimoDia = new Date(anoAtual, mesAtual + 1, 0)
      .toISOString()
      .split("T")[0];

    const { data, error } = await supabase
      .from("eventos")
      .select("*")
      .gte("data", primeiroDia)
      .lte("data", ultimoDia)
      .order("data", { ascending: true })
      .order("horario", { ascending: true });

    if (error) {
      console.error(error);
      return;
    }

    setEventos(data || []);
  }

  function abrirNovoEvento() {
    setEventoEditando(null);
    setTitulo("");
    setData("");
    setHorario("");
    setLocal("");
    setDescricao("");
    setMostrarFormulario(true);
  }

  function abrirEditarEvento(evento: Evento) {
    setEventoEditando(evento);

    setTitulo(evento.titulo);
    setData(evento.data);
    setHorario(evento.horario?.slice(0, 5) || "");
    setLocal(evento.local);
    setDescricao(evento.descricao || "");

    setMostrarFormulario(true);
  }

  async function salvarEvento() {
    if (!titulo || !data || !horario || !local) {
      alert("Preencha título, data, horário e local.");
      return;
    }

    if (eventoEditando) {
      const { error } = await supabase
        .from("eventos")
        .update({
          titulo,
          data,
          horario,
          local,
          descricao,
        })
        .eq("id", eventoEditando.id);

      if (error) {
        console.error(error);
        alert("Não foi possível editar o evento.");
        return;
      }
    } else {
      const { error } = await supabase.from("eventos").insert({
        titulo,
        data,
        horario,
        local,
        descricao,
      });

      if (error) {
        console.error(error);
        alert("Não foi possível criar o evento.");
        return;
      }
    }

    setMostrarFormulario(false);
    carregarEventos();
  }

  async function excluirEvento(id: number) {
    const confirmar = confirm("Deseja realmente excluir este evento?");

    if (!confirmar) return;

    const { error } = await supabase
      .from("eventos")
      .delete()
      .eq("id", id);

    if (error) {
      console.error(error);
      alert("Não foi possível excluir o evento.");
      return;
    }

    setEventoSelecionado(null);
    carregarEventos();
  }

  /* =========================
     NAVEGAÇÃO
  ========================= */

  function mesAnterior() {
    if (mesAtual === 0) {
      setMesAtual(11);
      setAnoAtual(anoAtual - 1);
    } else {
      setMesAtual(mesAtual - 1);
    }
  }

  function proximoMes() {
    if (mesAtual === 11) {
      setMesAtual(0);
      setAnoAtual(anoAtual + 1);
    } else {
      setMesAtual(mesAtual + 1);
    }
  }

  /* =========================
     DATAS
  ========================= */

  function formatarData(dataEvento: string) {
    const [ano, mes, dia] = dataEvento.split("-").map(Number);

    return {
      dia,
      mes: mesesAbrev[mes - 1],
      dataCompleta: `${dia} de ${meses[mes - 1]} de ${ano}`,
    };
  }

  function calcularDias(dataEvento: string) {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const [ano, mes, dia] = dataEvento.split("-").map(Number);

    const dataAlvo = new Date(ano, mes - 1, dia);
    dataAlvo.setHours(0, 0, 0, 0);

    const diferenca =
      dataAlvo.getTime() - hoje.getTime();

    return Math.ceil(diferenca / (1000 * 60 * 60 * 24));
  }

  const eventosDoMes = useMemo(() => {
    return eventos;
  }, [eventos]);

  const proximoEvento = eventosDoMes.length > 0
    ? eventosDoMes[0]
    : null;

  /* =========================
     WHATSAPP
  ========================= */

  function compartilharWhatsApp() {
    const mensagem =
      "📅 *Calendário EJC*\n\n" +
      "Confira os próximos eventos e tudo que acontece no EJC:\n\n" +
      window.location.href;

    const url =
      `https://wa.me/?text=${encodeURIComponent(mensagem)}`;

    window.open(url, "_blank");
  }

  if (carregandoUsuario) {
    return (
      <main className="loading-screen">
        <div className="loading-logo">
          EJC
        </div>
      </main>
    );
  }

  return (
    <main className="page">

      {/* =========================
          DECORAÇÕES DOURADAS
      ========================= */}

      <div className="decor decorTopLeft">
        <svg viewBox="0 0 300 360">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M15 315 C45 250, 35 190, 80 135 C110 98, 150 78, 182 52" />
            <path d="M65 246 C43 214, 28 181, 32 143" />
            <path d="M90 206 C120 178, 138 151, 151 119" />

            <path d="M76 157 C44 141, 26 115, 27 91 C28 66, 50 53, 70 63 C90 73, 94 96, 82 116" />
            <path d="M78 157 C110 141, 130 114, 128 89 C126 64, 104 52, 84 63 C65 74, 63 98, 75 117" />

            <path d="M76 157 C60 136, 60 110, 76 97 C91 84, 111 91, 116 108 C121 126, 104 145, 76 157" />

            <path d="M65 246 C37 235, 18 218, 13 198 C35 193, 57 204, 65 246" />
            <path d="M89 206 C111 205, 132 192, 142 174 C118 169, 98 180, 89 206" />
          </g>
        </svg>
      </div>

      <div className="decor decorTopRight">
        <svg viewBox="0 0 260 240">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.35"
            strokeLinecap="round"
          >
            <path d="M245 20 C205 50, 188 90, 184 135 C181 168, 192 196, 217 218" />
            <path d="M210 73 C190 65, 172 67, 160 79 C178 91, 196 90, 210 73" />
            <path d="M190 133 C210 121, 226 122, 239 135 C220 148, 202 147, 190 133" />
            <path d="M183 176 C163 165, 146 168, 135 182 C153 192, 171 190, 183 176" />

            <path d="M216 54 C225 48, 236 50, 240 59 C244 68, 238 77, 229 81 C221 75, 216 65, 216 54Z" />
          </g>
        </svg>
      </div>

      <div className="decor decorBottomLeft">
        <svg viewBox="0 0 260 300">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.25"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M18 285 C42 246, 68 223, 74 183 C79 151, 66 124, 39 104" />
            <path d="M74 183 C104 167, 125 142, 130 111" />
            <path d="M57 221 C36 211, 20 194, 18 174 C39 174, 56 192, 57 221" />
            <path d="M88 162 C108 160, 125 149, 136 131 C115 127, 97 138, 88 162" />

            <path d="M47 76 C48 52, 62 34, 80 29 C84 51, 72 69, 47 76" />
            <path d="M47 76 C27 68, 15 53, 15 37 C32 39, 46 53, 47 76" />
          </g>
        </svg>
      </div>

      <div className="decor decorBottomRight">
        <svg viewBox="0 0 300 340">
          <g
            fill="none"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M285 330 C258 285, 248 247, 259 205 C270 162, 252 124, 215 95" />

            <path d="M252 244 C226 229, 208 205, 207 179 C231 183, 250 204, 252 244" />

            <path d="M257 205 C281 190, 293 166, 289 143 C268 148, 255 172, 257 205" />

            <path d="M215 95 C190 82, 174 59, 176 36 C198 41, 215 63, 215 95" />

            <path d="M216 95 C239 85, 252 64, 250 43 C229 48, 216 68, 216 95" />

            <path d="M195 137 C207 125, 209 109, 203 97 C190 107, 187 123, 195 137" />

            <path d="M207 179 C188 166, 172 165, 159 176 C176 188, 193 188, 207 179" />
          </g>
        </svg>
      </div>

      {/* pequenos brilhos */}

      <span className="goldStar star1">✦</span>
      <span className="goldStar star2">✦</span>
      <span className="goldStar star3">✦</span>
      <span className="goldStar star4">✦</span>
      <span className="goldStar star5">✦</span>

      {/* =========================
          CONTEÚDO
      ========================= */}

      <div className="content">

        {/* HEADER */}

        <header className="header">

          <div className="brand">

            <div className="logoArea">
              <img
                src="/logo-ejc.png"
                alt="EJC - Encontro de Jovens com Cristo"
                className="logo"
              />
            </div>

            <div className="brandDivider" />

            <div className="titleArea">
              <span className="smallTitle">
                CALENDÁRIO DE
              </span>

              <h1>Eventos</h1>

              <span className="subtitle">
                ENCONTRO DE JOVENS COM CRISTO
              </span>

              <div className="titleDecoration">
                <span />
                <b>♡</b>
                <span />
              </div>
            </div>

          </div>

          <div className="headerButtons">

            <button
              className="outlineButton"
              onClick={compartilharWhatsApp}
            >
              <span>✦</span>
              Compartilhar
            </button>

            {usuario ? (
              <>
                <button
                  className="outlineButton"
                  onClick={abrirNovoEvento}
                >
                  + Novo evento
                </button>

                <button
                  className="outlineButton"
                  onClick={sair}
                >
                  Sair
                </button>
              </>
            ) : (
              <button
                className="outlineButton"
                onClick={() => setMostrarLogin(true)}
              >
                ♟ Área da equipe
              </button>
            )}

          </div>

        </header>

        {/* =========================
            PRÓXIMO EVENTO
        ========================= */}

        {proximoEvento && (
          <section
            className="featuredEvent"
            onClick={() => setEventoSelecionado(proximoEvento)}
          >

            <div className="featuredDate">

              <div className="nextBadge">
                PRÓXIMO EVENTO
              </div>

              <strong>
                {formatarData(proximoEvento.data).dia}
              </strong>

              <span className="featuredMonth">
                {formatarData(proximoEvento.data).mes}
              </span>

              <div className="featuredInfo">
                <span>
                  ◷ {proximoEvento.horario.slice(0, 5)}
                </span>

                <span>
                  ♢ {proximoEvento.local}
                </span>
              </div>

            </div>

            <div className="featuredContent">

              <h2>{proximoEvento.titulo}</h2>

              <p>
                {proximoEvento.descricao ||
                  "Um encontro especial de oração, comunhão e muita alegria."}
              </p>

              <div className="daysBadge">
                ◷{" "}
                {calcularDias(proximoEvento.data) > 0
                  ? `Faltam ${calcularDias(proximoEvento.data)} dias`
                  : calcularDias(proximoEvento.data) === 0
                  ? "É hoje!"
                  : "Evento realizado"}
              </div>

            </div>

          </section>
        )}

        {/* =========================
            MÊS
        ========================= */}

        <section className="monthSection">

          <div className="monthNavigation">

            <button
              className="monthArrow"
              onClick={mesAnterior}
            >
              ‹
            </button>

            <div className="monthTitle">
              <h2>{meses[mesAtual]}</h2>

              <span>{anoAtual}</span>
            </div>

            <button
              className="monthArrow"
              onClick={proximoMes}
            >
              ›
            </button>

          </div>

          <p className="monthDescription">
            Confira tudo o que acontece no EJC neste mês.
          </p>

          <div className="monthDecoration">
            <span />
            <b>♡</b>
            <span />
          </div>

        </section>

        {/* =========================
            EVENTOS
        ========================= */}

        {eventosDoMes.length === 0 ? (

          <div className="emptyState">

            <div className="emptySymbol">✦</div>

            <h3>
              Nenhum evento neste mês
            </h3>

            <p>
              Em breve teremos novidades por aqui.
            </p>

            {usuario && (
              <button
                className="goldButton"
                onClick={abrirNovoEvento}
              >
                Adicionar evento
              </button>
            )}

          </div>

        ) : (

          <section className="eventsGrid">

            {eventosDoMes.map((evento) => {

              const info = formatarData(evento.data);

              return (
                <article
                  key={evento.id}
                  className="eventCard"
                  onClick={() =>
                    setEventoSelecionado(evento)
                  }
                >

                  <div className="cardTop">

                    <div>
                      <strong>
                        {info.dia}
                      </strong>

                      <span>
                        {info.mes}
                      </span>
                    </div>

                    <div className="timeBox">
                      <small>
                        HORÁRIO:
                      </small>

                      <b>
                        {evento.horario.slice(0, 5)}
                      </b>
                    </div>

                  </div>

                  <h3>
                    {evento.titulo}
                  </h3>

                  <p>
                    {evento.descricao ||
                      "Evento do EJC. Clique para visualizar todos os detalhes."}
                  </p>

                  <div className="cardBottom">
                    <span>
                      ♢ {evento.local}
                    </span>

                    <b>→</b>
                  </div>

                </article>
              );
            })}

          </section>

        )}

        {/* =========================
            RODAPÉ
        ========================= */}

        <footer className="footer">

          <div className="footerDecoration">
            <span />
            <b>♡</b>
            <span />
          </div>

          <p>
            EJC • Encontro de Jovens com Cristo
          </p>

          <small>
            Paróquia de Sant’Ana do Barroso
          </small>

        </footer>

      </div>

      {/* =========================
          MODAL EVENTO
      ========================= */}

      {eventoSelecionado && (

        <div
          className="modalOverlay"
          onClick={() => setEventoSelecionado(null)}
        >

          <div
            className="eventModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() => setEventoSelecionado(null)}
            >
              ×
            </button>

            <span className="modalLabel">
              EVENTO DO EJC
            </span>

            <h2>
              {eventoSelecionado.titulo}
            </h2>

            <div className="modalDivider" />

            <div className="modalInfo">

              <div>
                <small>DATA</small>
                <strong>
                  {formatarData(eventoSelecionado.data).dataCompleta}
                </strong>
              </div>

              <div>
                <small>HORÁRIO</small>
                <strong>
                  {eventoSelecionado.horario.slice(0, 5)}
                </strong>
              </div>

              <div>
                <small>LOCAL</small>
                <strong>
                  {eventoSelecionado.local}
                </strong>
              </div>

            </div>

            {eventoSelecionado.descricao && (
              <p className="modalDescription">
                {eventoSelecionado.descricao}
              </p>
            )}

            {usuario && (
              <div className="modalActions">

                <button
                  className="editButton"
                  onClick={() => {
                    abrirEditarEvento(eventoSelecionado);
                    setEventoSelecionado(null);
                  }}
                >
                  Editar
                </button>

                <button
                  className="deleteButton"
                  onClick={() =>
                    excluirEvento(eventoSelecionado.id)
                  }
                >
                  Excluir
                </button>

              </div>
            )}

          </div>

        </div>

      )}

      {/* =========================
          LOGIN
      ========================= */}

      {mostrarLogin && (

        <div
          className="modalOverlay"
          onClick={() => setMostrarLogin(false)}
        >

          <div
            className="loginModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() => setMostrarLogin(false)}
            >
              ×
            </button>

            <div className="loginSymbol">
              ✦
            </div>

            <span className="modalLabel">
              ÁREA RESTRITA
            </span>

            <h2>
              Área da equipe
            </h2>

            <p>
              Entre para gerenciar os eventos do EJC.
            </p>

            <input
              type="email"
              placeholder="E-mail"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
            />

            <input
              type="password"
              placeholder="Senha"
              value={senha}
              onChange={(e) =>
                setSenha(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  entrar();
                }
              }}
            />

            <button
              className="loginButton"
              onClick={entrar}
            >
              Entrar
            </button>

          </div>

        </div>

      )}

      {/* =========================
          FORMULÁRIO
      ========================= */}

      {mostrarFormulario && (

        <div
          className="modalOverlay"
          onClick={() => setMostrarFormulario(false)}
        >

          <div
            className="formModal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="closeButton"
              onClick={() =>
                setMostrarFormulario(false)
              }
            >
              ×
            </button>

            <span className="modalLabel">
              ÁREA DA EQUIPE
            </span>

            <h2>
              {eventoEditando
                ? "Editar evento"
                : "Novo evento"}
            </h2>

            <div className="formGrid">

              <label>
                Título
                <input
                  value={titulo}
                  onChange={(e) =>
                    setTitulo(e.target.value)
                  }
                  placeholder="Ex.: Encontro do EJC"
                />
              </label>

              <label>
                Data
                <input
                  type="date"
                  value={data}
                  onChange={(e) =>
                    setData(e.target.value)
                  }
                />
              </label>

              <label>
                Horário
                <input
                  type="time"
                  value={horario}
                  onChange={(e) =>
                    setHorario(e.target.value)
                  }
                />
              </label>

              <label>
                Local
                <input
                  value={local}
                  onChange={(e) =>
                    setLocal(e.target.value)
                  }
                  placeholder="Ex.: Matriz Sant'Ana"
                />
              </label>

              <label className="full">
                Descrição
                <textarea
                  value={descricao}
                  onChange={(e) =>
                    setDescricao(e.target.value)
                  }
                  placeholder="Digite uma breve descrição do evento..."
                  rows={4}
                />
              </label>

            </div>

            <button
              className="saveButton"
              onClick={salvarEvento}
            >
              {eventoEditando
                ? "Salvar alterações"
                : "Adicionar evento"}
            </button>

          </div>

        </div>

      )}

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');

        :root {
          --bg: #f8fafc;
          --surface: #ffffff;
          --surface-soft: #f1f5f9;
          --border: #e2e8f0;
          --border-strong: #cbd5e1;
          --text: #0f172a;
          --text-secondary: #64748b;
          --text-muted: #94a3b8;
          --primary: #2563eb;
          --primary-hover: #1d4ed8;
          --primary-soft: #eff6ff;
          --danger: #dc2626;
          --radius-sm: 8px;
          --radius-md: 12px;
          --radius-lg: 16px;
          --shadow-sm: 0 1px 2px rgba(15, 23, 42, .04);
          --shadow-md: 0 4px 14px rgba(15, 23, 42, .07);
          --shadow-lg: 0 18px 45px rgba(15, 23, 42, .12);
          --transition: 180ms ease;
        }

        * { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
          margin: 0;
          background: var(--bg);
          color: var(--text);
          font-family: "DM Sans", Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          -webkit-font-smoothing: antialiased;
        }

        button, input, textarea { font: inherit; }
        button { cursor: pointer; }

        /* Página */

        .page {
          min-height: 100vh;
          position: relative;
          overflow-x: hidden;
          background: var(--bg);
        }

        /* Retira a decoração dourada anterior para deixar o layout realmente Clean Dashboard. */

        .decor,
        .goldStar {
          display: none;
        }

        .content {
          position: relative;
          z-index: 2;
          width: min(1180px, calc(100% - 40px));
          margin: 0 auto;
          padding: 28px 0 56px;
        }

        /* Header */

        .header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          padding: 18px 20px;
          margin-bottom: 20px;
          background: rgba(255,255,255,.92);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          box-shadow: var(--shadow-sm);
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 16px;
          min-width: 0;
        }

        .logoArea {
          width: 62px;
          min-width: 62px;
          height: 62px;
          display: grid;
          place-items: center;
        }

        .logo {
          width: 62px;
          height: 62px;
          object-fit: contain;
          transform: none;
        }

        .brandDivider {
          width: 1px;
          height: 42px;
          background: var(--border);
        }

        .titleArea {
          min-width: 0;
          padding: 0;
        }

        .smallTitle {
          display: block;
          margin-bottom: 2px;
          color: var(--text-muted);
          font-size: 10px;
          font-weight: 700;
          letter-spacing: .12em;
          text-transform: uppercase;
        }

        .titleArea h1 {
          margin: 0;
          color: var(--text);
          font-size: 28px;
          line-height: 1.1;
          font-weight: 700;
          letter-spacing: -.035em;
          font-style: normal;
          font-family: inherit;
        }

        .subtitle {
          display: block;
          margin-top: 4px;
          color: var(--text-secondary);
          font-size: 10px;
          font-weight: 500;
          letter-spacing: .08em;
        }

        .titleDecoration {
          display: none;
        }

        .headerButtons {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 8px;
          flex-wrap: wrap;
        }

        .outlineButton {
          min-height: 38px;
          border: 1px solid var(--border);
          background: var(--surface);
          color: var(--text-secondary);
          border-radius: 10px;
          padding: 0 13px;
          font-size: 12px;
          font-weight: 600;
          transition: background var(--transition), border-color var(--transition), color var(--transition), box-shadow var(--transition), transform var(--transition);
        }

        .outlineButton:hover {
          background: var(--surface-soft);
          border-color: var(--border-strong);
          color: var(--text);
          box-shadow: var(--shadow-sm);
          transform: translateY(-1px);
        }

        /* Próximo evento */

        .featuredEvent {
          display: grid;
          grid-template-columns: 180px 1fr;
          min-height: 180px;
          overflow: hidden;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: var(--radius-lg);
          cursor: pointer;
          box-shadow: var(--shadow-md);
          transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
        }

        .featuredEvent:hover {
          transform: translateY(-2px);
          border-color: #d6dee9;
          box-shadow: var(--shadow-lg);
        }

        .featuredDate {
          position: relative;
          padding: 34px 22px 20px;
          display: flex;
          flex-direction: column;
          background: var(--primary);
          color: white;
        }

        .nextBadge {
          position: absolute;
          left: 0;
          top: 0;
          padding: 7px 11px;
          border-radius: 0 0 9px 0;
          background: #dbeafe;
          color: #1e40af;
          font-size: 8px;
          font-weight: 800;
          letter-spacing: .04em;
        }

        .featuredDate strong {
          margin-top: 4px;
          color: white;
          font-size: 58px;
          line-height: .9;
          font-weight: 700;
          letter-spacing: -.06em;
        }

        .featuredMonth {
          margin-top: 7px;
          color: #dbeafe;
          font-size: 14px;
          font-weight: 700;
        }

        .featuredInfo {
          display: flex;
          flex-direction: column;
          gap: 5px;
          margin-top: auto;
          color: #dbeafe;
          font-size: 10px;
        }

        .featuredContent {
          min-width: 0;
          padding: 30px 34px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          color: var(--text);
        }

        .featuredContent h2 {
          margin: 0 0 8px;
          font-size: 24px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -.025em;
        }

        .featuredContent p {
          max-width: 700px;
          margin: 0 0 16px;
          color: var(--text-secondary);
          font-size: 13px;
          line-height: 1.6;
        }

        .daysBadge {
          width: fit-content;
          padding: 7px 11px;
          border: 1px solid #bfdbfe;
          border-radius: 8px;
          background: var(--primary-soft);
          color: #1d4ed8;
          font-size: 11px;
          font-weight: 600;
        }

        /* Mês */

        .monthSection {
          padding: 30px 0 20px;
          text-align: center;
        }

        .monthNavigation {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 14px;
        }

        .monthArrow {
          width: 38px;
          height: 38px;
          display: grid;
          place-items: center;
          border: 1px solid var(--border);
          border-radius: 10px;
          background: var(--surface);
          color: var(--text-secondary);
          font-size: 24px;
          line-height: 1;
          box-shadow: var(--shadow-sm);
          transition: background var(--transition), border-color var(--transition), color var(--transition), transform var(--transition);
        }

        .monthArrow:hover {
          background: var(--primary-soft);
          border-color: #bfdbfe;
          color: var(--primary);
          transform: translateY(-1px);
        }

        .monthTitle h2 {
          margin: 0;
          color: var(--text);
          font-size: 30px;
          line-height: 1.1;
          font-weight: 700;
          letter-spacing: -.035em;
          font-family: inherit;
          font-style: normal;
        }

        .monthTitle span {
          display: block;
          margin-top: 3px;
          color: var(--text-muted);
          font-size: 11px;
          font-weight: 600;
          letter-spacing: .08em;
        }

        .monthDescription {
          margin: 8px 0 0;
          color: var(--text-secondary);
          font-size: 12px;
        }

        .monthDecoration {
          display: none;
        }

        /* Eventos */

        .eventsGrid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 14px;
        }

        .eventCard {
          min-width: 0;
          min-height: 210px;
          padding: 17px;
          display: flex;
          flex-direction: column;
          background: var(--surface);
          color: var(--text);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          cursor: pointer;
          box-shadow: var(--shadow-sm);
          transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition), background var(--transition);
        }

        .eventCard:hover {
          transform: translateY(-2px);
          border-color: #cbd5e1;
          box-shadow: var(--shadow-md);
          background: #ffffff;
        }

        .cardTop {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 10px;
        }

        .cardTop > div:first-child strong {
          display: block;
          color: var(--text);
          font-size: 34px;
          line-height: .95;
          font-weight: 700;
          letter-spacing: -.05em;
        }

        .cardTop > div:first-child span {
          display: block;
          margin-top: 5px;
          color: var(--primary);
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
        }

        .timeBox {
          min-width: 78px;
          padding: 7px 9px;
          border: 1px solid #dbeafe;
          border-radius: 8px;
          background: var(--primary-soft);
          color: #1e40af;
        }

        .timeBox small {
          display: block;
          font-size: 7px;
          font-weight: 700;
          letter-spacing: .04em;
        }

        .timeBox b {
          display: block;
          margin-top: 2px;
          font-size: 12px;
          font-weight: 700;
        }

        .eventCard h3 {
          margin: 18px 0 6px;
          color: var(--text);
          font-size: 16px;
          line-height: 1.25;
          font-weight: 700;
          letter-spacing: -.015em;
        }

        .eventCard p {
          min-height: 42px;
          margin: 0;
          color: var(--text-secondary);
          font-size: 11px;
          line-height: 1.55;
        }

        .cardBottom {
          margin-top: auto;
          padding-top: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          border-top: 1px solid var(--border);
          color: var(--text-secondary);
          font-size: 10px;
          font-weight: 500;
        }

        .cardBottom b {
          color: var(--primary);
          font-size: 18px;
          font-weight: 600;
        }

        /* Estado vazio */

        .emptyState {
          padding: 55px 20px;
          text-align: center;
          background: var(--surface);
          border: 1px dashed var(--border-strong);
          border-radius: var(--radius-lg);
        }

        .emptySymbol {
          width: 42px;
          height: 42px;
          margin: 0 auto 12px;
          display: grid;
          place-items: center;
          border-radius: 12px;
          background: var(--primary-soft);
          color: var(--primary);
        }

        .emptyState h3 {
          margin: 0 0 5px;
          color: var(--text);
          font-size: 18px;
        }

        .emptyState p {
          margin: 0 0 18px;
          color: var(--text-secondary);
          font-size: 13px;
        }

        .goldButton {
          border: 0;
          border-radius: 9px;
          padding: 10px 15px;
          background: var(--primary);
          color: white;
          font-size: 12px;
          font-weight: 600;
          transition: background var(--transition), transform var(--transition);
        }

        .goldButton:hover {
          background: var(--primary-hover);
          transform: translateY(-1px);
        }

        /* Footer */

        .footer {
          padding: 38px 0 0;
          text-align: center;
        }

        .footerDecoration {
          display: none;
        }

        .footer p {
          margin: 0 0 4px;
          color: var(--text-secondary);
          font-size: 10px;
          font-weight: 600;
          letter-spacing: .05em;
        }

        .footer small {
          color: var(--text-muted);
          font-size: 10px;
        }

        /* Modais */

        .modalOverlay {
          position: fixed;
          inset: 0;
          z-index: 100;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          background: rgba(15, 23, 42, .48);
          backdrop-filter: blur(5px);
        }

        .eventModal,
        .loginModal,
        .formModal {
          position: relative;
          width: min(520px, 100%);
          padding: 28px;
          background: var(--surface);
          color: var(--text);
          border: 1px solid var(--border);
          border-radius: 18px;
          box-shadow: var(--shadow-lg);
        }

        .formModal {
          width: min(650px, 100%);
          max-height: 90vh;
          overflow-y: auto;
        }

        .closeButton {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 34px;
          height: 34px;
          display: grid;
          place-items: center;
          border: 1px solid var(--border);
          border-radius: 9px;
          background: var(--surface);
          color: var(--text-secondary);
          font-size: 20px;
          transition: background var(--transition), color var(--transition);
        }

        .closeButton:hover {
          background: var(--surface-soft);
          color: var(--text);
        }

        .modalLabel {
          display: block;
          margin-bottom: 7px;
          color: var(--primary);
          font-size: 9px;
          font-weight: 700;
          letter-spacing: .08em;
        }

        .eventModal h2,
        .loginModal h2,
        .formModal h2 {
          margin: 0;
          color: var(--text);
          font-family: inherit;
          font-size: 24px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -.025em;
        }

        .modalDivider {
          height: 1px;
          margin: 18px 0;
          background: var(--border);
        }

        .modalInfo {
          display: grid;
          gap: 14px;
        }

        .modalInfo small {
          display: block;
          margin-bottom: 3px;
          color: var(--text-muted);
          font-size: 8px;
          font-weight: 700;
          letter-spacing: .08em;
        }

        .modalInfo strong {
          color: var(--text);
          font-size: 13px;
          font-weight: 600;
        }

        .modalDescription {
          margin: 20px 0 0;
          color: var(--text-secondary);
          font-size: 13px;
          line-height: 1.6;
        }

        .modalActions {
          display: flex;
          gap: 8px;
          margin-top: 22px;
        }

        .editButton,
        .deleteButton {
          border: 0;
          border-radius: 9px;
          padding: 10px 15px;
          font-size: 12px;
          font-weight: 600;
          transition: transform var(--transition), background var(--transition);
        }

        .editButton {
          background: var(--primary);
          color: white;
        }

        .editButton:hover {
          background: var(--primary-hover);
          transform: translateY(-1px);
        }

        .deleteButton {
          background: #fef2f2;
          color: var(--danger);
        }

        .deleteButton:hover {
          background: #fee2e2;
        }

        .loginSymbol {
          width: 40px;
          height: 40px;
          margin-bottom: 12px;
          display: grid;
          place-items: center;
          border-radius: 10px;
          background: var(--primary-soft);
          color: var(--primary);
          font-size: 18px;
        }

        .loginModal > p {
          margin: 8px 0 20px;
          color: var(--text-secondary);
          font-size: 13px;
        }

        .loginModal input,
        .formModal input,
        .formModal textarea {
          width: 100%;
          border: 1px solid var(--border);
          border-radius: 9px;
          outline: none;
          padding: 11px 12px;
          background: var(--surface);
          color: var(--text);
          font-size: 13px;
          transition: border-color var(--transition), box-shadow var(--transition);
        }

        .loginModal input {
          margin-bottom: 10px;
        }

        .loginModal input::placeholder,
        .formModal input::placeholder,
        .formModal textarea::placeholder {
          color: var(--text-muted);
        }

        .loginModal input:focus,
        .formModal input:focus,
        .formModal textarea:focus {
          border-color: #93c5fd;
          box-shadow: 0 0 0 3px rgba(37,99,235,.10);
        }

        .loginButton,
        .saveButton {
          width: 100%;
          margin-top: 4px;
          border: 0;
          border-radius: 9px;
          padding: 12px;
          background: var(--primary);
          color: white;
          font-size: 13px;
          font-weight: 600;
          transition: background var(--transition), transform var(--transition);
        }

        .loginButton:hover,
        .saveButton:hover {
          background: var(--primary-hover);
          transform: translateY(-1px);
        }

        .formGrid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
          margin-top: 22px;
        }

        .formGrid label {
          display: flex;
          flex-direction: column;
          gap: 6px;
          color: var(--text-secondary);
          font-size: 11px;
          font-weight: 600;
        }

        .formGrid label.full {
          grid-column: 1 / -1;
        }

        .formGrid textarea {
          min-height: 100px;
          resize: vertical;
        }

        .saveButton {
          margin-top: 18px;
        }

        /* Loading */

        .loading-screen {
          min-height: 100vh;
          display: grid;
          place-items: center;
          background: var(--bg);
        }

        .loading-logo {
          color: var(--primary);
          font-size: 30px;
          font-weight: 700;
        }

        /* Responsivo */

        @media (max-width: 900px) {
          .content {
            width: min(720px, calc(100% - 28px));
          }

          .header {
            align-items: flex-start;
            flex-direction: column;
          }

          .headerButtons {
            width: 100%;
            justify-content: flex-start;
          }

          .eventsGrid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        @media (max-width: 650px) {
          .content {
            width: calc(100% - 16px);
            padding-top: 12px;
          }

          .header {
            padding: 15px;
            margin-bottom: 12px;
          }

          .logoArea,
          .logo {
            width: 48px;
            min-width: 48px;
            height: 48px;
          }

          .brand {
            gap: 10px;
          }

          .brandDivider {
            height: 34px;
          }

          .smallTitle {
            font-size: 8px;
            letter-spacing: .08em;
          }

          .titleArea h1 {
            font-size: 23px;
          }

          .subtitle {
            font-size: 7px;
            letter-spacing: .04em;
          }

          .headerButtons {
            gap: 6px;
          }

          .outlineButton {
            min-height: 35px;
            padding: 0 10px;
            font-size: 10px;
          }

          .featuredEvent {
            grid-template-columns: 94px 1fr;
            min-height: 165px;
          }

          .featuredDate {
            padding: 31px 12px 15px;
          }

          .featuredDate strong {
            font-size: 43px;
          }

          .featuredMonth {
            font-size: 12px;
          }

          .featuredInfo {
            font-size: 8px;
          }

          .featuredContent {
            padding: 20px 15px;
          }

          .featuredContent h2 {
            font-size: 18px;
          }

          .featuredContent p {
            font-size: 10px;
          }

          .monthSection {
            padding: 22px 0 14px;
          }

          .monthTitle h2 {
            font-size: 25px;
          }

          .monthArrow {
            width: 34px;
            height: 34px;
          }

          .eventsGrid {
            grid-template-columns: 1fr;
            gap: 10px;
          }

          .eventCard {
            min-height: 185px;
          }

          .formGrid {
            grid-template-columns: 1fr;
          }

          .formGrid label.full {
            grid-column: auto;
          }

          .eventModal,
          .loginModal,
          .formModal {
            padding: 24px 18px;
          }
        }
      `}</style>

    </main>
  );
}